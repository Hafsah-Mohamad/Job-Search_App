import React, { useEffect, useState } from "react";
import io from "socket.io-client";

const Chat = ({ senderId, receiverId }) => {
  const [messages, setMessages] = useState([]); // علشان نخزن الرسائل
  const [newMessage, setNewMessage] = useState(""); // علشان نخزن الرسالة الجديدة

  const socket = io("http://localhost:3000"); // الاتصال بالسيرفر

  useEffect(() => {
    // استقبال رسالة جديدة
    socket.on("receiveMessage", (data) => {
      setMessages((prevMessages) => [...prevMessages, data]);
    });

    // تنظيف الـ Socket عند الخروج
    return () => {
      socket.disconnect();
    };
  }, []);

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      socket.emit("sendMessage", { senderId, receiverId, message: newMessage });
      setNewMessage("");
    }
  };

  return (
    <div>
      <div>
        {messages.map((msg, index) => (
          <div key={index}>
            <strong>{msg.senderId}:</strong> {msg.message}
          </div>
        ))}
      </div>
      <input
        type="text"
        value={newMessage}
        onChange={(e) => setNewMessage(e.target.value)}
      />
      <button onClick={handleSendMessage}>Send</button>
    </div>
  );
};

export default Chat;
