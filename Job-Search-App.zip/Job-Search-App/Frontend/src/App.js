import React from "react";
import Chat from "../components/Chat";

const App = () => {
  const senderId = "64f1c8e8f1c8e8f1c8e8f1c8";
  const receiverId = "64f1c8e8f1c8e8f1c8e8f1c9";

  return (
    <div>
      <h1>Chat Application</h1>
      <Chat senderId={senderId} receiverId={receiverId} />
    </div>
  );
};

export default App;
