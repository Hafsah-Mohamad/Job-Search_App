const { GraphQLSchema } = require("graphql");
const RootQuery = require("./types/RootQuery");
const Mutation = require("./types/Mutation");

module.exports = new GraphQLSchema({
  query: RootQuery,
  mutation: Mutation,
});
