const { GraphQLObjectType, GraphQLString, GraphQLID } = require("graphql");
const User = require("../../models/User");
const Company = require("./models/Company");

const Mutation = new GraphQLObjectType({
  name: "Mutation",
  fields: {
    banOrUnbanUser: {
      type: GraphQLString,
      args: {
        id: { type: GraphQLID },
        action: { type: GraphQLString }, // 'ban' أو 'unban'
      },
      async resolve(parent, { id, action }) {
        const user = await User.findById(id);
        if (!user) throw new Error("User not found");

        if (action === "ban") {
          user.bannedAt = new Date();
        } else if (action === "unban") {
          user.bannedAt = null;
        } else {
          throw new Error("Invalid action");
        }

        await user.save();
        return `User ${action === "ban" ? "banned" : "unbanned"} successfully`;
      },
    },
    approveCompany: {
      type: GraphQLString,
      args: {
        id: { type: GraphQLID },
      },
      async resolve(parent, { id }) {
        const company = await Company.findById(id);
        if (!company) throw new Error("Company not found");

        company.approvedByAdmin = true;
        await company.save();
        return "Company approved successfully";
      },
    },
  },
});

module.exports = Mutation;
