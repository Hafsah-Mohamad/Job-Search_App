const { GraphQLObjectType, GraphQLList } = require("graphql");
const UserType = require("./UserType");
const CompanyType = require("./CompanyType");
const User = require("../../models/User");
const Company = require("./models/Company");

const RootQuery = new GraphQLObjectType({
  name: "RootQueryType",
  fields: {
    users: {
      type: new GraphQLList(UserType),
      resolve() {
        return User.find(); // جلب كل المستخدمين
      },
    },
    companies: {
      type: new GraphQLList(CompanyType),
      resolve() {
        return Company.find(); // جلب كل الشركات
      },
    },
  },
});

module.exports = RootQuery;
