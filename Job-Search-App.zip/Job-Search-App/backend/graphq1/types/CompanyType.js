const { GraphQLObjectType, GraphQLID, GraphQLString } = require("graphql");

const CompanyType = new GraphQLObjectType({
  name: "Company",
  fields: {
    id: { type: GraphQLID },
    companyName: { type: GraphQLString },
    companyEmail: { type: GraphQLString },
    industry: { type: GraphQLString },
    approvedByAdmin: { type: GraphQLString },
    bannedAt: { type: GraphQLString },
  },
});

module.exports = CompanyType;
