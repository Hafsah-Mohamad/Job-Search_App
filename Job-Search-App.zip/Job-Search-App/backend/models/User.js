const mongoose = require("mongoose");
const bcrypt = require("bcrypt");

const UserSchema = new mongoose.Schema(
  {
    firstName: {
      type: String,
      required: true,
      trim: true, // إزالة المسافات الزائدة
    },
    lastName: {
      type: String,
      required: true,
      trim: true, // إزالة المسافات الزائدة
    },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true, // تحويل الإيميل لحروف صغيرة
    },
    password: {
      type: String,
      required: true,
    },
    mobileNumber: {
      type: String,
      required: true,
    },
    OTP: [
      {
        code: String,
        type: String,
        expiresIn: Date,
      },
    ],
    isConfirmed: {
      type: Boolean,
      default: false,
    },
    role: {
      type: String,
      enum: ["User", "Admin", "HR"], // قيم محددة
      default: "User",
    },
    gender: {
      type: String,
      enum: ["Male", "Female"], // قيم محددة
    },
    dob: {
      type: Date,
      validate: {
        validator: function (value) {
          // التحقق من العمر (أكبر من 18)
          const age = new Date().getFullYear() - value.getFullYear();
          return age >= 18;
        },
        message: "يجب أن يكون العمر أكبر من 18",
      },
    },
  },
  { timestamps: true },
); // إضافة timestamps (createdAt, updatedAt)

// Middleware لتشفير الباسورد قبل الحفظ
UserSchema.pre("save", async function (next) {
  if (this.isModified("password")) {
    this.password = await bcrypt.hash(this.password, 10);
  }
  next();
});

// Method لفك تشفير mobileNumber
UserSchema.methods.getActualMobileNumber = function () {
  return decryptData(this.mobileNumber);
};

// دالة لفك تشفير البيانات (مثال بسيط)
const decryptData = (data) => {
  return data; // هنا نستخدم أي طريقة لفك التشفير (مثل AES)
};

// Method للـ Soft Delete
UserSchema.methods.softDelete = function () {
  this.deletedAt = new Date();
  return this.save();
};

// تصدير الـ Model
module.exports = mongoose.model("User", UserSchema);
