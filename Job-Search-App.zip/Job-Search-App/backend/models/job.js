const mongoose = require("mongoose");

const JobSchema = new mongoose.Schema(
  {
    jobTitle: {
      type: String,
      required: true,
    },
    jobLocation: {
      type: String,
      enum: ["onsite", "remotely", "hybrid"],
      required: true,
    },
    workingTime: {
      type: String,
      enum: ["part-time", "full-time"],
      required: true,
    },
    seniorityLevel: {
      type: String,
      enum: ["fresh", "Junior", "Mid-Level", "Senior", "Team-Lead", "CTO"],
      required: true,
    },
    technicalSkills: [
      {
        type: String,
      },
    ],
    softSkills: [
      {
        type: String,
      },
    ],
    companyId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Company",
      required: true,
    },
  },
  { timestamps: true },
);

const jobSchema = new mongoose.Schema({
  jobTitle: { type: String, required: true },
  jobLocation: { type: String, enum: ["onsite", "remotely", "hybrid"] },
  workingTime: { type: String, enum: ["part-time", "full-time"] },
  seniorityLevel: {
    type: String,
    enum: ["fresh", "Junior", "Mid-Level", "Senior", "Team-Lead", "CTO"],
  },
  jobDescription: { type: String },
  technicalSkills: [{ type: String }],
  softSkills: [{ type: String }],
  addedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  closed: { type: Boolean, default: false },
  companyId: { type: mongoose.Schema.Types.ObjectId, ref: "Company" },
});
jobSchema.virtual("applications", {
  ref: "Application",
  localField: "_id",
  foreignField: "jobId",
});

module.exports = mongoose.model("Job", JobSchema, jobSchema);
