const mongoose = require("mongoose");

const CompanySchema = new mongoose.Schema(
  {
    companyName: {
      type: String,
      required: true,
      unique: true,
    },
    description: {
      type: String,
      required: true,
    },
    industry: {
      type: String,
      required: true,
    },
    address: {
      type: String,
      required: true,
    },
    numberOfEmployees: {
      type: String,
      validate: {
        validator: function (value) {
          // التحقق من نطاق عدد الموظفين
          const range = value.split("-").map(Number);
          return range.length === 2 && range[0] <= range[1];
        },
        message: "يجب أن يكون نطاق الموظفين صحيح",
      },
    },
    companyEmail: {
      type: String,
      unique: true,
      required: true,
    },
    CreatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    Logo: {
      secure_url: String,
      public_id: String,
    },
    coverPic: {
      secure_url: String,
      public_id: String,
    },
    legalAttachment: {
      secure_url: String,
      public_id: String,
    },
    approvedByAdmin: {
      type: Boolean,
      default: false,
    },
    bannedAt: {
      type: Date,
    },
    deletedAt: {
      type: Date,
    },
  },
  CompanySchema.pre("remove", async function (next) {
    const companyId = this._id;
    // Delete related jobs
    await Job.deleteMany({ companyId });
    // Delete related chats
    await Chat.deleteMany({ companyId });
    next();
  }),
  { timestamps: true },
);

module.exports = mongoose.model("Company", CompanySchema);
