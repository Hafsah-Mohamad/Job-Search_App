const express = require("express");
const {
  createJob,
  updateJob,
  addJob,
} = require("../controllers/jobController");
const router = express.Router();

router.post("/create", createJob);
router.put("/update/:id", updateJob);
router.post("/add", addJob);
router.delete("/delete/:id", deleteJob);
router.get("/:companyId", getJobs);
router.get("/:companyId/:jobId", getJobs);
router.get("/filter", getJobsWithFilters);
router.get("/applications/:jobId", getJobApplications);
router.post("/apply/:jobId", applyToJob);
router.put("/application/:applicationId", acceptOrRejectApplicant);
module.exports = router;
