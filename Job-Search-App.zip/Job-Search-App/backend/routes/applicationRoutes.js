const express = require("express");
const {
  applyForJob,
  updateApplicationStatus,
} = require("../controllers/applicationController");
const router = express.Router();

router.post("/apply", applyForJob);
router.put("/update-status/:id", updateApplicationStatus);

module.exports = router;
