const express = require("express");
const {
  registerUser,
  loginUser,
  updateUser,
} = require("../controllers/userController");
const router = express.Router();

router.post("/register", registerUser);
router.post("/login", loginUser);
router.put("/update/:id", updateUser);
router.get("/me", getLoginUserData);
router.get("/profile/:id", getProfileData);
router.put("/update-password", updatePassword);
router.put("/upload-profile-pic", uploadProfilePic);
router.put("/upload-cover-pic", uploadCoverPic);
router.delete("/delete-profile-pic", deleteProfilePic);
router.delete("/delete-cover-pic", deleteCoverPic);
router.delete("/soft-delete", softDeleteAccount);
module.exports = router;
