const express = require("express");
const router = express.Router();
const passport = require("passport");
const jwt = require("jsonwebtoken");

const {
  loginUser,
  updateUser,
  signUp,
} = require("../controllers/authController");
router.post("/login", loginUser); // هنا المفروض loginUser تكون function
router.put("/update/:id", updateUser);
router.post("/signup", signUp);
router.post("/confirm-otp", confirmOTP);
router.post("/signin", signIn);
router.get(
  "/google",
  passport.authenticate("google", { scope: ["profile", "email"] }),
);
router.get(
  "/google/callback",
  passport.authenticate("google", { session: false }),
  (req, res) => {
    const accessToken = jwt.sign({ id: req.user._id }, process.env.JWT_SECRET, {
      expiresIn: "1h",
    });
    res.status(200).json({ accessToken });
  },
);
router.post("/forget-password", sendOTPForForgetPassword);
router.post("/reset-password", resetPassword);
router.post("/refresh-token", refreshToken);
module.exports = router;
