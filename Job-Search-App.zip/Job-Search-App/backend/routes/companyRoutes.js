const express = require("express");
const {
  createCompany,
  updateCompany,
  addCompany,
  deleteCompany,
} = require("../controllers/companyController");
const router = express.Router();
const authMiddleware = require("../middlewares/authMiddleware");
router.post("/create", createCompany);
router.put("/update/:id", updateCompany);
router.post("/add", addCompany);
router.put("/update/:id", updateCompany);
router.delete("/soft-delete/:id", softDeleteCompany);
router.get("/:id", getCompanyWithJobs);
router.get("/search", searchCompanyByName);
router.put("/upload-logo/:id", uploadCompanyLogo);
router.put("/upload-cover-pic/:id", uploadCompanyCoverPic);
router.delete("/delete-logo/:id", deleteCompanyLogo);
router.delete("/delete-cover-pic/:id", deleteCompanyCoverPic);
router.post("/", authMiddleware, createCompany);
router.put("/:id", authMiddleware, updateCompany);
router.delete("/:id", authMiddleware, deleteCompany);
module.exports = router;
