const express = require("express");
const {
  sendMessage,
  getMessages,
  getChatHistory,
  sendMessage,
} = require("../controllers/chatController");
const router = express.Router();

router.post("/send", sendMessage);
router.get("/messages/:senderId/:receiverId", getMessages);
router.get("/history/:senderId/:receiverId", getChatHistory);
router.post("/send", sendMessage);
module.exports = router;
