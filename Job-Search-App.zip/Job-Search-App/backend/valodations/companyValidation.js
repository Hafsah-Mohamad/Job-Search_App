const Joi = require("joi");

const companySchema = Joi.object({
  companyName: Joi.string().required(),
  description: Joi.string().required(),
  industry: Joi.string().required(),
  address: Joi.string().required(),
  numberOfEmployees: Joi.string().required(),
  companyEmail: Joi.string().email().required(),
  CreatedBy: Joi.string().required(),
});

const validateCompany = (data) => {
  return companySchema.validate(data);
};

module.exports = validateCompany;
