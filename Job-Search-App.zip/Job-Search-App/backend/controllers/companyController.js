const Company = require("./backend/models/company.js");
const validateCompany = require("../validations/companyValidation");

const createCompany = async (req, res) => {
  // 1. الفاليديشن
  const { error } = validateCompany(req.body);
  if (error) return res.status(400).json({ message: error.details[0].message });

  // 2. محاولة إنشاء الشركة
  try {
    const {
      companyName,
      description,
      industry,
      address,
      numberOfEmployees,
      companyEmail,
      CreatedBy,
    } = req.body;
    const company = new Company({
      companyName,
      description,
      industry,
      address,
      numberOfEmployees,
      companyEmail,
      CreatedBy,
    });
    await company.save();
    res.status(201).json({ message: "Company created successfully" });
  } catch (error) {
    // 3. معالجة الأخطاء
    res.status(500).json({ error: error.message });
  }
};

const updateCompany = async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;
    const company = await Company.findByIdAndUpdate(id, updates, { new: true });
    res.status(200).json(company);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const addCompany = async (req, res) => {
  try {
    const {
      companyName,
      companyEmail,
      description,
      industry,
      address,
      numberOfEmployees,
      CreatedBy,
    } = req.body;

    // التحقق من وجود الشركة بنفس الاسم أو الإيميل
    const existingCompany = await Company.findOne({
      $or: [{ companyName }, { companyEmail }],
    });
    if (existingCompany)
      return res.status(400).json({ message: "Company already exists" });

    const company = new Company({
      companyName,
      companyEmail,
      description,
      industry,
      address,
      numberOfEmployees,
      CreatedBy,
    });

    await company.save();
    res.status(201).json({ message: "Company added successfully", company });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const UpdateCompany = async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;
    const userId = req.user.id; // نأخذ الـ id من الـ token

    const company = await Company.findById(id);
    if (!company) return res.status(404).json({ message: "Company not found" });

    // التحقق من أن المستخدم هو مالك الشركة
    if (company.CreatedBy.toString() !== userId) {
      return res
        .status(403)
        .json({ message: "You are not authorized to update this company" });
    }

    // تحديث البيانات
    const allowedUpdates = [
      "companyName",
      "description",
      "industry",
      "address",
      "numberOfEmployees",
    ];
    allowedUpdates.forEach((update) => {
      if (updates[update]) company[update] = updates[update];
    });

    await company.save();
    res.status(200).json({ message: "Company updated successfully", company });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const softDeleteCompany = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id; // نأخذ الـ id من الـ token
    const userRole = req.user.role; // نأخذ الـ role من الـ token

    const company = await Company.findById(id);
    if (!company) return res.status(404).json({ message: "Company not found" });

    // التحقق من أن المستخدم هو مالك الشركة أو أدمن
    if (company.CreatedBy.toString() !== userId && userRole !== "Admin") {
      return res
        .status(403)
        .json({ message: "You are not authorized to delete this company" });
    }

    company.deletedAt = new Date(); // Soft Delete
    await company.save();

    res.status(200).json({ message: "Company soft deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const getCompanyWithJobs = async (req, res) => {
  try {
    const { id } = req.params;

    const company = await Company.findById(id).populate("jobs");
    if (!company) return res.status(404).json({ message: "Company not found" });

    res.status(200).json({ company });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const searchCompanyByName = async (req, res) => {
  try {
    const { name } = req.query;

    const companies = await Company.find({
      companyName: { $regex: name, $options: "i" },
    });
    res.status(200).json({ companies });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const uploadCompanyLogo = async (req, res) => {
  try {
    const { id } = req.params;
    const { logo } = req.body;

    const company = await Company.findById(id);
    if (!company) return res.status(404).json({ message: "Company not found" });

    company.Logo = logo;
    await company.save();

    res
      .status(200)
      .json({ message: "Company logo uploaded successfully", company });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const uploadCompanyCoverPic = async (req, res) => {
  try {
    const { id } = req.params;
    const { coverPic } = req.body;

    const company = await Company.findById(id);
    if (!company) return res.status(404).json({ message: "Company not found" });

    company.coverPic = coverPic;
    await company.save();

    res
      .status(200)
      .json({
        message: "Company cover picture uploaded successfully",
        company,
      });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const deleteCompanyLogo = async (req, res) => {
  try {
    const { id } = req.params;

    const company = await Company.findById(id);
    if (!company) return res.status(404).json({ message: "Company not found" });

    company.Logo = null;
    await company.save();

    res
      .status(200)
      .json({ message: "Company logo deleted successfully", company });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const deleteCompanyCoverPic = async (req, res) => {
  try {
    const { id } = req.params;

    const company = await Company.findById(id);
    if (!company) return res.status(404).json({ message: "Company not found" });

    company.coverPic = null;
    await company.save();

    res
      .status(200)
      .json({ message: "Company cover picture deleted successfully", company });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = {
  createCompany,
  updateCompany,
  addCompany,
  UpdateCompany,
  softDeleteCompany,
  getCompanyWithJobs,
  searchCompanyByName,
  uploadCompanyLogo,
  uploadCompanyCoverPic,
  deleteCompanyLogo,
  deleteCompanyCoverPic,
};
