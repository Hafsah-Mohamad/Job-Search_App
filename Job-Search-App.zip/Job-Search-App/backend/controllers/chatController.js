const Chat = require("../models/chat");

const sendMessage = async (req, res) => {
  try {
    const { senderId, receiverId, message } = req.body;
    let chat = await Chat.findOne({ senderId, receiverId });
    if (!chat) {
      chat = new Chat({ senderId, receiverId, messages: [] });
    }
    chat.messages.push({ message, senderId });
    await chat.save();
    res.status(201).json({ message: "Message sent successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const getMessages = async (req, res) => {
  try {
    const { senderId, receiverId } = req.params;
    const chat = await Chat.findOne({ senderId, receiverId });
    if (!chat) return res.status(404).json({ message: "No messages found" });
    res.status(200).json(chat.messages);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const Chat = require("./models/Chat");

const getChatHistory = async (req, res) => {
  try {
    const { senderId, receiverId } = req.params;

    const chat = await Chat.findOne({
      $or: [
        { senderId, receiverId },
        { senderId: receiverId, receiverId: senderId },
      ],
    }).populate("messages.senderId", "firstName lastName");

    if (!chat)
      return res.status(404).json({ message: "No chat history found" });

    res.status(200).json({ chat });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = { sendMessage, getMessages, getChatHistory };
