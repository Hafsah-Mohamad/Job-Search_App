const User = require("../models/User");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const registerUser = async (req, res) => {
  try {
    const { firstName, lastName, email, password, gender, DOB, mobileNumber } =
      req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({
      firstName,
      lastName,
      email,
      password: hashedPassword,
      gender,
      DOB,
      mobileNumber,
    });
    await user.save();
    res.status(201).json({ message: "User registered successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: "User not found" });
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch)
      return res.status(400).json({ message: "Invalid credentials" });
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: "1h",
    });
    res.status(200).json({ token });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const updateUser = async (req, res) => {
  try {
    const { id } = req.params;
    const { mobileNumber, DOB, firstName, lastName, gender } = req.body;

    // البحث عن المستخدم
    const user = await User.findById(id);
    if (!user) return res.status(404).json({ message: "User not found" });

    // تحديث البيانات
    if (mobileNumber) user.mobileNumber = await encryptData(mobileNumber); // تشفير mobileNumber
    if (DOB) user.DOB = DOB;
    if (firstName) user.firstName = firstName;
    if (lastName) user.lastName = lastName;
    if (gender) user.gender = gender;

    await user.save();
    res.status(200).json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// دالة لتشفير البيانات
const encryptData = async (data) => {
  const encrypted = await bcrypt.hash(data, 10);
  return encrypted;
};
const getLoginUserData = async (req, res) => {
  try {
    const { id } = req.user; // نأخذ الـ id من الـ token
    const user = await User.findById(id);
    if (!user) return res.status(404).json({ message: "User not found" });

    const userData = {
      firstName: user.firstName,
      lastName: user.lastName,
      mobileNumber: user.getActualMobileNumber(), // فك تشفير mobileNumber
      DOB: user.DOB,
      gender: user.gender,
    };

    res.status(200).json(userData); // إرجاع بيانات المستخدم
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const updatePassword = async (req, res) => {
  try {
    const { id } = req.user; // نأخذ الـ id من الـ token
    const { oldPassword, newPassword } = req.body;

    const user = await User.findById(id);
    if (!user) return res.status(404).json({ message: "User not found" });

    // التحقق من كلمة المرور القديمة
    const isMatch = await bcrypt.compare(oldPassword, user.password);
    if (!isMatch)
      return res.status(400).json({ message: "Invalid old password" });

    // تحديث كلمة المرور
    user.password = await bcrypt.hash(newPassword, 10);
    await user.save();

    res.status(200).json({ message: "Password updated successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const uploadProfilePic = async (req, res) => {
  try {
    const { id } = req.user;
    const { profilePic } = req.body;

    const user = await User.findById(id);
    if (!user) return res.status(404).json({ message: "User not found" });

    user.profilePic = profilePic;
    await user.save();

    res.status(200).json({ message: "Profile picture updated successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const uploadCoverPic = async (req, res) => {
  try {
    const { id } = req.user;
    const { coverPic } = req.body;

    const user = await User.findById(id);
    if (!user) return res.status(404).json({ message: "User not found" });

    user.coverPic = coverPic;
    await user.save();

    res.status(200).json({ message: "Cover picture updated successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const deleteProfilePic = async (req, res) => {
  try {
    const { id } = req.user;

    const user = await User.findById(id);
    if (!user) return res.status(404).json({ message: "User not found" });

    user.profilePic = null;
    await user.save();

    res.status(200).json({ message: "Profile picture deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const deleteCoverPic = async (req, res) => {
  try {
    const { id } = req.user;

    const user = await User.findById(id);
    if (!user) return res.status(404).json({ message: "User not found" });

    user.coverPic = null;
    await user.save();

    res.status(200).json({ message: "Cover picture deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const softDeleteAccount = async (req, res) => {
  try {
    const { id } = req.user;

    const user = await User.findById(id);
    if (!user) return res.status(404).json({ message: "User not found" });

    await user.softDelete();
    res.status(200).json({ message: "Account soft deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = {
  registerUser,
  loginUser,
  updateUser,
  getLoginUserData,
  updatePassword,
  uploadProfilePic,
  uploadCoverPic,
  deleteProfilePic,
  deleteCoverPic,
  softDeleteAccount,
};
