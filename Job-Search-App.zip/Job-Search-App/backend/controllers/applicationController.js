const Application = require("../models/Application");

const applyForJob = async (req, res) => {
  try {
    const { jobId, userId, userCV } = req.body;
    const application = new Application({ jobId, userId, userCV });
    await application.save();
    res.status(201).json({ message: "Application submitted successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const updateApplicationStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const application = await Application.findByIdAndUpdate(
      id,
      { status },
      { new: true },
    );
    res.status(200).json(application);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = { applyForJob, updateApplicationStatus };
