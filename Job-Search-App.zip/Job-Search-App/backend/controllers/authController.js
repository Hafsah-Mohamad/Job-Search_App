const User = require("../models/User");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const nodemailer = require("nodemailer");

const signUp = async (req, res) => {
  try {
    const { firstName, lastName, email, password, mobileNumber } = req.body;

    // التحقق من وجود الإيميل
    const existingUser = await User.findOne({ email });
    if (existingUser)
      return res.status(400).json({ message: "Email already exists" });

    // إنشاء OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const otpExpires = new Date(Date.now() + 10 * 60 * 1000); // 10 دقائق

    // حفظ المستخدم مع OTP
    const user = new User({
      firstName,
      lastName,
      email,
      password,
      mobileNumber,
      OTP: [
        {
          code: await bcrypt.hash(otp, 10),
          type: "confirmEmail",
          expiresIn: otpExpires,
        },
      ],
    });
    await user.save();

    // إرسال OTP إلى الإيميل
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });

    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: "OTP for Email Verification",
      text: `Your OTP is: ${otp}`,
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.log(error);
        return res.status(500).json({ message: "Failed to send OTP" });
      }
      res.status(201).json({ message: "OTP sent successfully" });
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const confirmOTP = async (req, res) => {
  try {
    const { email, otp } = req.body;

    // البحث عن المستخدم
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: "User not found" });

    // التحقق من الـ OTP
    const otpData = user.OTP.find((otpData) => otpData.type === "confirmEmail");
    if (!otpData) return res.status(400).json({ message: "OTP not found" });

    // التحقق من تاريخ الانتهاء
    if (otpData.expiresIn < new Date())
      return res.status(400).json({ message: "OTP expired" });

    // التحقق من قيمة الـ OTP
    const isMatch = await bcrypt.compare(otp, otpData.code);
    if (!isMatch) return res.status(400).json({ message: "Invalid OTP" });

    // تأكيد الإيميل
    user.isConfirmed = true;
    await user.save();

    res.status(200).json({ message: "Email confirmed successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const signIn = async (req, res) => {
  try {
    const { email, password } = req.body;

    // البحث عن المستخدم
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: "User not found" });

    // التحقق من الباسورد
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch)
      return res.status(400).json({ message: "Invalid credentials" });

    // إنشاء Tokens
    const accessToken = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: "1h",
    });
    const refreshToken = jwt.sign(
      { id: user._id },
      process.env.JWT_REFRESH_SECRET,
      { expiresIn: "7d" },
    );

    res.status(200).json({ accessToken, refreshToken });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const sendOTPForForgetPassword = async (req, res) => {
  try {
    const { email } = req.body;

    // البحث عن المستخدم
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: "User not found" });

    // إنشاء OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const otpExpires = new Date(Date.now() + 10 * 60 * 1000); // 10 دقائق

    // حفظ OTP
    user.OTP.push({
      code: await bcrypt.hash(otp, 10),
      type: "forgetPassword",
      expiresIn: otpExpires,
    });
    await user.save();

    // إرسال OTP إلى الإيميل
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });

    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: "OTP for Password Reset",
      text: `Your OTP is: ${otp}`,
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.log(error);
        return res.status(500).json({ message: "Failed to send OTP" });
      }
      res.status(200).json({ message: "OTP sent successfully" });
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const resetPassword = async (req, res) => {
  try {
    const { email, otp, newPassword } = req.body;

    // البحث عن المستخدم
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: "User not found" });

    // التحقق من الـ OTP
    const otpData = user.OTP.find(
      (otpData) => otpData.type === "forgetPassword",
    );
    if (!otpData) return res.status(400).json({ message: "OTP not found" });

    // التحقق من تاريخ الانتهاء
    if (otpData.expiresIn < new Date())
      return res.status(400).json({ message: "OTP expired" });

    // التحقق من قيمة الـ OTP
    const isMatch = await bcrypt.compare(otp, otpData.code);
    if (!isMatch) return res.status(400).json({ message: "Invalid OTP" });

    // تحديث الباسورد
    user.password = newPassword;
    await user.save();

    res.status(200).json({ message: "Password reset successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const refreshToken = async (req, res) => {
  try {
    const { refreshToken } = req.body;

    // التحقق من الـ Refresh Token
    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
    const user = await User.findById(decoded.id);
    if (!user) return res.status(404).json({ message: "User not found" });

    // التحقق من تاريخ تغيير الباسورد
    if (
      user.changeCredentialTime &&
      new Date(user.changeCredentialTime) > new Date(decoded.iat * 1000)
    ) {
      return res.status(400).json({ message: "Token expired" });
    }

    // إنشاء Access Token جديد
    const accessToken = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: "1h",
    });

    res.status(200).json({ accessToken });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const getProfileData = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await User.findById(id);
    if (!user) return res.status(404).json({ message: "User not found" });

    const profileData = {
      userName: `${user.firstName} ${user.lastName}`,
      mobileNumber: user.getActualMobileNumber(), // فك تشفير mobileNumber
      profilePic: user.profilePic,
      coverPic: user.coverPic,
    };

    res.status(200).json(profileData);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = {
  signUp,
  confirmOTP,
  signIn,
  sendOTPForForgetPassword,
  resetPassword,
  refreshToken,
  getProfileData,
};

// دالة التسجيل
//rts.registerUser = async (req, res) => {
//y {
//const { firstName, lastName, email, password } = req.body;
//
//// التحقق من وجود المستخدم مسبقاً
//let existingUser = await User.findOne({ email });
//if (existingUser) {
//  return res.status(400).json({ message: 'المستخدم موجود بالفعل' });
//}
//
//// إنشاء مستخدم جديد
//const newUser = new User({
//  firstName,
//  lastName,
//  email,
//  password
//});
//
//await newUser.save();

//    res.status(201).json({ message: 'Registration completed successfully' });
//  } catch (error) {
//    res.status(500).json({ message: ' Sothing wrong  ', error: error.message });
//  }
//};

// دالة تسجيل الدخول

const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: "User not found" });
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch)
      return res.status(400).json({ message: "Invalid credentials" });
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: "1h",
    });
    res.status(200).json({ token });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = { loginUser }; // دي أهم حاجة
