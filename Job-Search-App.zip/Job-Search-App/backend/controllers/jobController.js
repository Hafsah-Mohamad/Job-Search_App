const Job = require("../models/job");
const Company = require("../models/Company");

const createJob = async (req, res) => {
  try {
    const {
      jobTitle,
      jobLocation,
      workingTime,
      seniorityLevel,
      jobDescription,
      technicalSkills,
      softSkills,
      addedBy,
      companyId,
    } = req.body;
    const job = new Job({
      jobTitle,
      jobLocation,
      workingTime,
      seniorityLevel,
      jobDescription,
      technicalSkills,
      softSkills,
      addedBy,
      companyId,
    });
    await job.save();
    res.status(201).json({ message: "Job created successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const updateJob = async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;
    const job = await Job.findByIdAndUpdate(id, updates, { new: true });
    res.status(200).json(job);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const addJob = async (req, res) => {
  try {
    const {
      jobTitle,
      jobLocation,
      workingTime,
      seniorityLevel,
      jobDescription,
      technicalSkills,
      softSkills,
      companyId,
    } = req.body;
    const userId = req.user.id; // نأخذ الـ id من الـ token

    // التحقق من أن المستخدم هو HR أو مالك الشركة
    const company = await Company.findById(companyId);
    if (!company) return res.status(404).json({ message: "Company not found" });

    if (
      company.CreatedBy.toString() !== userId &&
      !company.HRs.includes(userId)
    ) {
      return res
        .status(403)
        .json({ message: "You are not authorized to add a job" });
    }

    const job = new Job({
      jobTitle,
      jobLocation,
      workingTime,
      seniorityLevel,
      jobDescription,
      technicalSkills,
      softSkills,
      addedBy: userId,
      companyId,
    });

    await job.save();
    res.status(201).json({ message: "Job added successfully", job });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const deleteJob = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id; // نأخذ الـ id من الـ token

    const job = await Job.findById(id);
    if (!job) return res.status(404).json({ message: "Job not found" });

    // التحقق من أن المستخدم هو HR أو مالك الشركة
    const company = await Company.findById(job.companyId);
    if (!company) return res.status(404).json({ message: "Company not found" });

    if (
      company.CreatedBy.toString() !== userId &&
      !company.HRs.includes(userId)
    ) {
      return res
        .status(403)
        .json({ message: "You are not authorized to delete this job" });
    }

    await job.remove();
    res.status(200).json({ message: "Job deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const getJobs = async (req, res) => {
  try {
    const { companyId, jobId } = req.params;
    const { page = 1, limit = 10, sort = "-createdAt" } = req.query;

    const query = { companyId };
    if (jobId) query._id = jobId;

    const jobs = await Job.find(query)
      .sort(sort)
      .skip((page - 1) * limit)
      .limit(limit);

    const totalCount = await Job.countDocuments(query);

    res.status(200).json({ jobs, totalCount });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const getJobsWithFilters = async (req, res) => {
  try {
    const {
      workingTime,
      jobLocation,
      seniorityLevel,
      jobTitle,
      technicalSkills,
    } = req.query;
    const { page = 1, limit = 10, sort = "-createdAt" } = req.query;

    const query = {};
    if (workingTime) query.workingTime = workingTime;
    if (jobLocation) query.jobLocation = jobLocation;
    if (seniorityLevel) query.seniorityLevel = seniorityLevel;
    if (jobTitle) query.jobTitle = { $regex: jobTitle, $options: "i" };
    if (technicalSkills)
      query.technicalSkills = { $in: technicalSkills.split(",") };

    const jobs = await Job.find(query)
      .sort(sort)
      .skip((page - 1) * limit)
      .limit(limit);

    const totalCount = await Job.countDocuments(query);

    res.status(200).json({ jobs, totalCount });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const getJobApplications = async (req, res) => {
  try {
    const { jobId } = req.params;
    const { page = 1, limit = 10, sort = "-createdAt" } = req.query;

    const job = await Job.findById(jobId).populate({
      path: "applications",
      populate: { path: "userId", select: "firstName lastName email" },
    });

    if (!job) return res.status(404).json({ message: "Job not found" });

    const applications = job.applications
      .sort((a, b) =>
        sort === "-createdAt"
          ? b.createdAt - a.createdAt
          : a.createdAt - b.createdAt,
      )
      .slice((page - 1) * limit, page * limit);

    const totalCount = job.applications.length;

    res.status(200).json({ applications, totalCount });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const applyToJob = async (req, res) => {
  try {
    const { jobId } = req.params;
    const { userCV } = req.body;
    const userId = req.user.id; // نأخذ الـ id من الـ token

    const job = await Job.findById(jobId);
    if (!job) return res.status(404).json({ message: "Job not found" });

    const application = new Application({
      jobId,
      userId,
      userCV,
    });

    await application.save();

    // إرسال إشعار للـ HR باستخدام Socket.io
    const company = await Company.findById(job.companyId);
    const hrIds = company.HRs;

    hrIds.forEach((hrId) => {
      io.to(hrId).emit("newApplication", { jobId, application });
    });

    res
      .status(201)
      .json({ message: "Application submitted successfully", application });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
const acceptOrRejectApplicant = async (req, res) => {
  try {
    const { applicationId } = req.params;
    const { status } = req.body; // 'accepted' أو 'rejected'
    const userId = req.user.id; // نأخذ الـ id من الـ token

    const application =
      await Application.findById(applicationId).populate("userId");
    if (!application)
      return res.status(404).json({ message: "Application not found" });

    const job = await Job.findById(application.jobId);
    if (!job) return res.status(404).json({ message: "Job not found" });

    const company = await Company.findById(job.companyId);
    if (!company) return res.status(404).json({ message: "Company not found" });

    // التحقق من أن المستخدم هو HR أو مالك الشركة
    if (
      company.CreatedBy.toString() !== userId &&
      !company.HRs.includes(userId)
    ) {
      return res
        .status(403)
        .json({ message: "You are not authorized to perform this action" });
    }

    application.status = status;
    await application.save();

    // إرسال بريد إلكتروني
    const emailText =
      status === "accepted"
        ? "Congratulations! Your application has been accepted."
        : "We regret to inform you that your application has been rejected.";
    sendEmail(application.userId.email, "Application Status", emailText);

    res.status(200).json({ message: `Application ${status} successfully` });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = { acceptOrRejectApplicant };
module.exports = {
  createJob,
  updateJob,
  addJob,
  deleteJob,
  getJobs,
  getJobsWithFilters,
  getJobApplications,
  applyToJob,
  acceptOrRejectApplicant,
};
