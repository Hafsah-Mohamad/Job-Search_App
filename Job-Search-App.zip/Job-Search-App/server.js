const express = require("express");
const http = require("http");
const socketIo = require("socket.io");
const { graphqlHTTP } = require("express-graphql");
const mongoose = require("mongoose");
const passport = require("passport");
const dotenv = require("dotenv");
const rateLimit = require("express-rate-limit");
const helmet = require("helmet");
const cors = require("cors");
const bodyParser = require("body-parser");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const cron = require("node-cron");
const User = require("./backend/models/User");
const Company = require("./backend/models/company.js");
const chat = require("./backend/models/chat");
const schema = require("./backend/graphq1/schema");
const userRoutes = require("./backend/routes/userRoutes");
const companyRoutes = require("./backend/routes/companyRoutes");
const jobRoutes = require("./backend/routes/jobRoutes");
const chatRoutes = require("./backend/routes/chatRoutes");
const applicationRoutes = require("./backend/routes/applicationRoutes");
const authRoutes = require("./backend/routes/authRoutes");

dotenv.config();

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// Middleware
app.use(cors());
app.use(express.json());
app.use(bodyParser.json());
app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);
app.use("/api/companies", companyRoutes);
app.use("/api/jobs", jobRoutes);
app.use("/api/chat", chatRoutes);
app.use("/api/applications", applicationRoutes);
app.use(
  "/graphql",
  graphqlHTTP({
    schema,
    graphiql: true,
  }),
);

app.get("/", (req, res) => {
  res.send("Hello World!");
});

app.post("/api/auth/register", (req, res) => {
  try {
    const { firstName, lastName, email, password } = req.body;
    console.log("Received data:", req.body);
    res.status(201).json({
      message: "تم التسجيل بنجاح",
      data: { firstName, lastName, email },
    });
  } catch (error) {
    console.error("خطأ في التسجيل:", error);
    res.status(500).json({
      message: "حدث خطأ أثناء التسجيل",
      error: error.message,
    });
  }
});
app.use(limiter);
app.use(helmet);
app.use(cors({ origin: "https://localhost:3000" }));

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: "Something went wrong!" });
});

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
});

const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: "User not found" });
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch)
      return res.status(400).json({ message: "Invalid credentials" });
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: "1h",
    });
    res.status(200).json({ token });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

cron.schedule("0 */6 * * *", async () => {
  try {
    await User.updateMany(
      {},
      { $pull: { OTP: { expiresIn: { $lt: new Date() } } } },
    );
    console.log("Expired OTPs deleted");
  } catch (error) {
    console.error("Error deleting expired OTPs:", error);
  }
});

io.on("connection", (socket) => {
  console.log("A user connected:", socket.id);

  socket.on("sendMessage", async (data) => {
    const { senderId, receiverId, message } = data;

    const sender = await User.findById(senderId);
    const company = await Company.findOne({
      $or: [{ CreatedBy: senderId }, { HRs: senderId }],
    });

    if (!company && sender.role !== "HR") {
      return socket.emit(
        "error",
        "Only HR or company owner can start a conversation",
      );
    }

    let chat = await Chat.findOne({
      $or: [
        { senderId, receiverId },
        { senderId: receiverId, receiverId: senderId },
      ],
    });

    if (!chat) {
      chat = new Chat({ senderId, receiverId, messages: [] });
    }

    chat.messages.push({ message, senderId });
    await chat.save();

    io.to(receiverId).emit("receiveMessage", { senderId, message });
  });

  socket.on("disconnect", () => {
    console.log("A user disconnected:", socket.id);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
